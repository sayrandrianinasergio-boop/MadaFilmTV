package com.madafilm.tv;
import android.annotation.SuppressLint; import android.os.Bundle; import android.webkit.WebSettings; import android.webkit.WebView; import android.webkit.WebViewClient; import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
 private static final String SERVER_URL="http://10.0.2.2:3000/";
 @SuppressLint("SetJavaScriptEnabled") @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);WebView w=findViewById(R.id.webView);w.setWebViewClient(new WebViewClient());WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);w.loadUrl(SERVER_URL);}
 @Override public void onBackPressed(){WebView w=findViewById(R.id.webView);if(w.canGoBack())w.goBack();else super.onBackPressed();}
}